<?php 
  session_start();
  if (!$_SESSION["kode_pengguna"]){
        header("Location:login.php");
  } else {

    include 'config/database.php';
    $kode_pengguna=$_SESSION["kode_pengguna"];
    $username=$_SESSION["username"];

    $hasil=mysqli_query($kon,"select username from pengguna where kode_pengguna='$kode_pengguna'");
    $data = mysqli_fetch_array($hasil); 
    $username_db=$data['username'];

    if ($username!=$username_db){
        session_unset();
        session_destroy();
        header("Location:login.php");
    }
  }
?>

<?php
    // Profil Aplikasi
    include 'config/database.php';
    $query = mysqli_query($kon, "select * from profil_aplikasi limit 1");    
    $row = mysqli_fetch_array($query);
    $nama_kampus=$row['nama_kampus'];
    $logo=$row['logo'];
?>

<!DOCTYPE html>
<html>
<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" href="apps/aplikasi/logo/<?php echo $logo; ?>">

    <!-- Title Website -->
    <title>SIAKAD | <?php echo $nama_kampus; ?></title>

    <!-- Bootstrap -->
    <link href="template/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="template/css/font-awesome.min.css" rel="stylesheet">

    <!-- Date Picker 3 -->
    <link href="template/css/datepicker3.css" rel="stylesheet">

    <!-- Local CSS -->
    <link href="template/css/styles.css" rel="stylesheet">

    <!-- jQuery -->
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <script src="template/js/jquery-2.2.3.min.js"></script>
    <script src="template/js/jquery-1.11.1.min.js"></script>

    <!-- Custom Font -->
    <link href="src/font/font.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <style>

        .no-js #loader { display: none;  }
        .js #loader { display: block; position: absolute; left: 100px; top: 0; }
        .se-pre-con {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url('loading.gif') center no-repeat #fff;
        }
    </style>

</head>
<body>

<nav class="navbar navbar-custom navbar-fixed-top bg-info" role="navigation">
    <div class="container-fluid"><!-- container-fluid -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span></button>
            <a class="navbar-brand" href="#"> SIAKAD | <?php echo $nama_kampus; ?></a>
        </div>
    </div><!-- /.container-fluid -->
</nav>

<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">

    <?php if ($_SESSION['level']=='Admin' or $_SESSION['level']=='admin'):?>
        <div class="profile-sidebar">
            <div class="profile-userpic">
                <img src="apps/admin/foto/<?php echo $_SESSION['foto'];?>" class="img-responsive" alt="">
            </div>
            <div class="profile-usertitle">
            <?php echo substr($_SESSION['nama_admin'],0,20); ?>
                <div class="profile-usertitle-name"><?php echo "Administrator"; ?></div>
                <div></div>
            </div>
            <div class="clear"></div>
        </div>
    <?php endif; ?>

    <?php if ($_SESSION['level']=='Dosen' or $_SESSION['level']=='dosen'):?>
        <div class="profile-sidebar">
            <div class="profile-userpic">
                <img src="apps/dosen/foto/<?php echo $_SESSION['foto'];?>" class="img-responsive" alt="">
            </div>
            <div class="profile-usertitle">
            <?php echo substr($_SESSION['nama_dosen'],0,20); ?>
                <div class="profile-usertitle-name"><?php echo "Dosen"; ?></div>
                <div></div>
            </div>
            <div class="clear"></div>
        </div>
    <?php endif; ?>

    <?php if ($_SESSION['level']=='Mahasiswa' or $_SESSION['level']=='mahasiswa'):?>
        <div class="profile-sidebar">
            <div class="profile-userpic">
                <img src="apps/mahasiswa/foto/<?php echo $_SESSION['foto'];?>" class="img-responsive" alt="">
            </div>
            <div class="profile-usertitle">
            <?php echo substr($_SESSION['nama_mahasiswa'],0,20); ?>
                <div class="profile-usertitle-name"><?php echo "Mahasiswa"; ?></div>
                <div></div>
            </div>
            <div class="clear"></div>
        </div>
    <?php endif; ?>

<!-- Side Bar Navigation -->
<div class="divider"></div>

    <!-- Menu Admin -->
    <ul class="nav menu">
		<li><a href='index.php?page=beranda'><em class='fa fa-home'>&nbsp;</em>  Beranda</a></li>
        <?php if ($_SESSION["level"]=="Admin" or $_SESSION['level']=='admin'): ?>

            <li><a href="index.php?page=admin" id="admin"><em class="fa fa-id-card">&nbsp;</em> Data Admin</a></li>
            <li><a href="index.php?page=dosen" id="dosen"><em class="fa fa-id-card">&nbsp;</em> Data Dosen</a></li>
            <li><a href="index.php?page=mahasiswa" id="mahasiswa"><em class="fa fa-id-card">&nbsp;</em> Data Mahasiswa</a></li>
            <li class="parent"><a data-toggle="collapse" href="#sub-item-1">
                <em class="fa fa-folder">&nbsp;</em> Data Umum <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
                    </a>
                <ul class="children collapse" id="sub-item-1">
                        <li><a class="" href="index.php?page=pengaturan-aplikasi">
                                <span class="fa fa-institution">&nbsp;</span> Profil Kampus
                            </a>
                        </li> 
                        <li><a class="" href="index.php?page=program-studi">
                                <span class="fa fa-navicon ">&nbsp;</span> Program Studi
                            </a>
                        </li>
                        <li><a class="" href="index.php?page=semester">
                                <span class="fa fa-line-chart">&nbsp;</span> Semester
                            </a>
                        </li>
                        <li><a class="" href="index.php?page=ruangan">
                                <span class="fa fa-map">&nbsp;</span> Ruangan
                            </a>
                        </li>
                        <li><a class="" href="index.php?page=matakuliah">
                                <span class="fa fa-newspaper-o">&nbsp;</span> Mata Kuliah
                            </a>
                        </li>
                </ul>
            </li>

            <li class="parent"><a data-toggle="collapse" href="#sub-item-2">
                <em class="fa fa-tasks">&nbsp;</em> Kelola Data <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
                    </a>
                <ul class="children collapse" id="sub-item-2">
                        <li><a class="" href="index.php?page=jadwal">
                                <span class="fa fa-calendar">&nbsp;</span> Jadwal Perkuliahan
                            </a>
                        </li>
                        <li><a class="" href="index.php?page=presensi">
                                <span class="fa fa-calendar-check-o">&nbsp;</span> Presensi
                            </a>
                        </li>          
                </ul>
            </li>

            <?php endif; ?>
    <!-- Menu Admin -->

    <!-- Menu Dosen -->
            <?php if ($_SESSION["level"]=="Dosen" or $_SESSION["level"]=="dosen"): ?>
                <li><a href="index.php?page=profil-dosen"><em class="fa fa-user-circle-o">&nbsp;</em> Profil</a></li>
                <li><a href="index.php?page=jadwal-mengajar"><em class="fa fa-calendar">&nbsp;</em> Jadwal Mengajar</a></li>
                <li><a href="index.php?page=nilai"><em class="fa fa-check-square-o">&nbsp;</em> Pengelolaan Nilai</a></li>
            <?php endif; ?>
    <!-- Menu Dosen -->

    <!-- Menu Mahasiswa -->
            <?php if ($_SESSION["level"]=="Mahasiswa" or $_SESSION["level"]=="mahasiswa"): ?>
                <li><a href="index.php?page=profil"><em class="fa fa-user-circle-o">&nbsp;</em> Profil</a></li>
                <li><a href="index.php?page=krs"><em class="fa fa-hourglass-2">&nbsp;</em> Kartu Rencana Studi</a></li>
                <li><a href="index.php?page=khs"><em class="fa fa-paper-plane">&nbsp;</em> Kartu Hasil Studi</a></li>
                <li><a href="index.php?page=transkrip-nilai"><em class="fa fa-tags">&nbsp;</em> Transkrip Nilai</a></li>
                <li><a href="index.php?page=rekap-presensi"><em class="fa fa-cube">&nbsp;</em> Rekap Presensi</a></li>
            <?php endif; ?>
    <!-- Menu Mahasiswa -->
    
    <!-- Menu Keluar -->    
            <li><a href="logout.php" id="keluar"><em class="fa fa-sign-out">&nbsp;</em> Keluar</a></li>
    </ul>
</div>
<!-- Side Bar Navigation -->

<!-- Function Page Penghubung -->
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">

    <?php 
          if(isset($_GET['page'])){
            $page = $_GET['page'];
        
            switch ($page) {
                case 'beranda':
                    include "apps/beranda/index.php";
                    break;
                case 'mahasiswa':
                    include "apps/mahasiswa/index.php";
                    break;
                case 'profil':
                    include "apps/mahasiswa/profil.php";
                    break;
                case 'dosen':
                    include "apps/dosen/index.php";
                    break;
                case 'profil-dosen':
                    include "apps/dosen/profil.php";
                    break;
                case 'jadwal-mengajar':
                    include "apps/dosen/jadwal-mengajar.php";
                    break;
                case 'admin':
                    include "apps/admin/index.php";
                    break;
                case 'matakuliah':
                    include "apps/matakuliah/index.php";
                    break;
                case 'program-studi':
                    include "apps/program-studi/index.php";
                    break;
                case 'ruangan':
                    include "apps/ruangan/index.php";
                    break;
                case 'semester':
                    include "apps/semester/index.php";
                    break;
                case 'jadwal':
                    include "apps/jadwal/index.php";
                    break;
                case 'krs':
                    include "apps/krs/index.php";
                    break;
                case 'khs':
                    include "apps/khs/index.php";
                    break;
                case 'transkrip-nilai':
                    include "apps/transkrip-nilai/index.php";
                    break;
                case 'nilai':
                    include "apps/nilai/index.php";
                    break;
                case 'presensi':
                    include "apps/presensi/index.php";
                    break;
                case 'rekap-presensi':
                    include "apps/presensi-mhs/index.php";
                    break;
                case 'pengaturan-aplikasi':
                    include "apps/aplikasi/index.php";
                    break;
              default:
                echo "<center><h3>Maaf. Halaman Tidak Di Temukan !</h3></center>";
                break;
            }
          }
      ?>
<!-- Function Page Penghubung -->

    <!--/.row-->
</div>
<!--/.main-->

<!-- Java Script -->
<script src="template/js/bootstrap.min.js"></script>
<script src="template/js/chart.min.js"></script>
<script src="template/js/chart-data.js"></script>
<script src="template/js/easypiechart.js"></script>
<script src="template/js/easypiechart-data.js"></script>
<script src="template/js/bootstrap-datepicker.js"></script>
<script src="template/js/custom.js"></script>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">

<script src="/assets/chart/chart.js"></script>

<script>
   // fungsi hapus jadwal
   $('#keluar').on('click',function(){
        konfirmasi=confirm("Apakah Anda Yakin Ingin Keluar?")
        if (konfirmasi){
            return true;
        }else {
            return false;
        }
    });
</script>
<!-- Java Script -->

</body>
</html>