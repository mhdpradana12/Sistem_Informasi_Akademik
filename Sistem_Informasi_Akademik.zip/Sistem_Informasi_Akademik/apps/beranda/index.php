<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=beranda">
                <em class="fa fa-home"></em>
            </a></li>
        <li class="active">Beranda</li>
    </ol>
</div>
<!--/.row-->
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">Beranda</div>
            <div class="panel-body">

            <!--Menampilkan Nama Pengguna Sesuai Level -->
            <?php if ($_SESSION['level']=='Admin' or $_SESSION['level']=='Admin'):?>
                <h3>Selamat Datang,  <?php echo  $_SESSION["nama_admin"]; ?>.</h3>
            <?php endif; ?>
            <?php if ($_SESSION['level']=='Dosen' or $_SESSION['level']=='dosen'):?>
                <h3>Selamat Datang, <?php echo  $_SESSION["nama_dosen"]; ?>.</h3>
            <?php endif; ?>
            <?php if ($_SESSION['level']=='Mahasiswa' or $_SESSION['level']=='mahasiswa'):?>
                <h3>Selamat Datang, <?php echo  $_SESSION["nama_mahasiswa"]; ?>.</h3>
            <?php endif; ?>
            <!-- Menampilkan Nama Pengguna Sesuai Level -->

            <?php 
                //Mengambil profil aplikasi
                include 'config/database.php';
                $query = mysqli_query($kon, "select * from profil_aplikasi limit 1");    
                $row = mysqli_fetch_array($query);
            ?>

            <!-- Info Aplikasi -->
            <p>Selamat Datang di Sistem Informasi Akademi (SIAKAD). Sebuah sistem yang memungkinkan para civitas akademika <?php echo $row['nama_kampus'];?> untuk menerima informasi melalu web browser. Sistem ini diharapkan dapat memberi kemudahan setiap civitas akademika untuk melakukan aktivitas-aktivitas akademik.</p>
            <!-- Info Aplikasi -->
            
            </div>
        </div>
    </div>
</div>