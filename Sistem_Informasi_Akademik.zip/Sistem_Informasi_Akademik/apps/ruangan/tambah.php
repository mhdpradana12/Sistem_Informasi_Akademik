<?php
session_start();
    if (isset($_POST['tambah_ruangan'])) {
        
        //Include file koneksi, untuk koneksikan ke database
        include '../../config/database.php';
        
        //Fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        //Cek apakah ada kiriman form dari method post
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            //Memulai transaksi
            mysqli_query($kon,"START TRANSACTION");

            $kode_ruangan=input($_POST["kode_ruangan"]);
            $nama_ruangan=input($_POST["nama_ruangan"]);
            $kapasitas=input($_POST["kapasitas"]);

            $sql="insert into ruangan (kode_ruangan,nama_ruangan,kapasitas) values
            ('$kode_ruangan','$nama_ruangan','$kapasitas')";

            $simpan_ruangan=mysqli_query($kon,$sql);

            if ($simpan_ruangan) {
                mysqli_query($kon,"COMMIT");
                header("Location:../../index.php?page=ruangan&add=berhasil");
            }
            else {
                mysqli_query($kon,"ROLLBACK");
                header("Location:../../index.php?page=ruangan&add=gagal");
            }
        }
    }
?>

<?php
    // mengambil data ruangan dengan kode paling besar
    include '../../config/database.php';
    $query = mysqli_query($kon, "SELECT max(id_ruangan) as kodeTerbesar FROM ruangan");
    $data = mysqli_fetch_array($query);
    $id_ruangan = $data['kodeTerbesar'];
    $id_ruangan++;
    $huruf = "M";
    $koderuangan = $huruf . sprintf("%03s", $id_ruangan);
?>
<form action="apps/ruangan/tambah.php" method="post">
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Kode Ruangan :</label>
                <h3><?php echo $koderuangan; ?></h3>
                <input name="kode_ruangan" value="<?php echo $koderuangan; ?>" type="hidden" class="form-control">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Nama Ruangan :</label>
                <input type="text" name="nama_ruangan" class="form-control" placeholder="Masukan Nama Ruangan" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <label>Kapasitas :</label>
                <input type="number"  min="0" name="kapasitas" class="form-control" placeholder="Masukan Jumlah Kapasitas" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <button type="submit" name="tambah_ruangan" id="Submit" class="btn btn-success"><i class="fa fa-plus"></i> Tambah</button>
            <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> Reset</button>
        </div>
    </div>
</form>