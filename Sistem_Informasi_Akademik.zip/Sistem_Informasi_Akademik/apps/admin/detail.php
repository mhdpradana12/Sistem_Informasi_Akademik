<?php 
    include '../../config/database.php';
    $id_admin=$_POST["id_admin"];
    $sql="select * from admin where id_admin=$id_admin limit 1";
    $hasil=mysqli_query($kon,$sql);
    $data = mysqli_fetch_array($hasil); 
?>

<table class="table">
    <tbody>
        <tr>
            <td>Nomor Induk Pegawai (NIP)</td>
            <td width="75%">: <?php echo $data['nip'];?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td width="75%">: <?php echo $data['nama_admin'];?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td width="75%">: <?php echo $data['jk'] == 1 ? 'Laki-laki' : 'Perempuan';?></td>
        </tr>
        <tr>
            <td>email</td>
            <td width="75%">: <?php echo $data['email'];?></td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td width="75%">: <?php echo $data['no_telp'];?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td width="75%">: <?php echo $data['alamat'];?></td>
        </tr>
    </tbody>
</table>