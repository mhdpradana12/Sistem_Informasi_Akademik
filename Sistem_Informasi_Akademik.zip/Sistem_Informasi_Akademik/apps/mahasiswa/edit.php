<?php
session_start();
    if (isset($_POST['edit_mahasiswa'])) {
        
        //Include file koneksi, untuk koneksikan ke database
        include '../../config/database.php';
        
        //Fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        //Cek apakah ada kiriman form dari method post
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            //Memulai transaksi
            mysqli_query($kon,"START TRANSACTION");

            $id_mahasiswa=input($_POST["id_mahasiswa"]);
            $nama_mahasiswa=input($_POST["nama_mahasiswa"]);
            $nim=input($_POST["nim"]);
            $tempat_lahir=input($_POST["tempat_lahir"]);
            $tanggal_lahir=input($_POST["tanggal_lahir"]);
            $jk=input($_POST["jk"]);
            $kewarganegaraan=input($_POST["kewarganegaraan"]);
            $agama=input($_POST["agama"]);
            $nama_ibu=input($_POST["nama_ibu"]);
            $email=input($_POST["email"]);
            $no_telp=input($_POST["no_telp"]);
            $alamat=input($_POST["alamat"]);
            $kode_pos=input($_POST["kode_pos"]);
            $provinsi=input($_POST["provinsi"]);
            $kabupaten=input($_POST["kabupaten"]);
            $kecamatan=input($_POST["kecamatan"]);
            $pendidikan=input($_POST["pendidikan"]);
            $sekolah=input($_POST["sekolah"]);
            $nilai_raport=input($_POST["nilai_raport"]);
            $program_studi=input($_POST["program_studi"]);
            $id_semester=input($_POST["id_semester"]);
            $angkatan=input($_POST["angkatan"]);
            $dosen_pembimbing=input($_POST["dosen_pembimbing"]);
            
            $foto_saat_ini=$_POST['foto_saat_ini'];
            $foto_baru = $_FILES['foto_baru']['name'];
            $ekstensi_diperbolehkan	= array('png','jpg','jpeg','gif');
            $x = explode('.', $foto_baru);
            $ekstensi = strtolower(end($x));
            $ukuran	= $_FILES['foto_baru']['size'];
            $file_tmp = $_FILES['foto_baru']['tmp_name'];


            if (!empty($foto_baru)){
                if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
                    //Mengupload foto baru
                    move_uploaded_file($file_tmp, 'foto/'.$foto_baru);
    
                    //Menghapus foto lama, foto yang dihapus selain foto default
                    if ($foto_saat_ini!='foto_default.png'){
                        unlink("foto/".$foto_saat_ini);
                    }
                    
                    $sql="update mahasiswa set
                    nama_mahasiswa='$nama_mahasiswa',
                    nim='$nim',
                    tempat_lahir='$tempat_lahir',
                    tanggal_lahir='$tanggal_lahir',
                    jk='$jk',
                    kewarganegaraan='$kewarganegaraan',
                    agama='$agama',
                    email='$email',
                    no_telp='$no_telp',
                    alamat='$alamat',
                    kode_pos='$kode_pos',
                    provinsi='$provinsi',
                    kabupaten='$kabupaten',
                    kecamatan='$kecamatan',
                    pendidikan='$pendidikan',
                    sekolah='$sekolah',
                    angkatan='$angkatan',
                    id_program_studi='$program_studi',
                    id_semester='$id_semester',
                    dosen_pembimbing='$dosen_pembimbing',
                    foto='$foto_baru'
                    where id_mahasiswa=$id_mahasiswa";
                }
            }else {
                $sql="update mahasiswa set
                nama_mahasiswa='$nama_mahasiswa',
                nim='$nim',
                tempat_lahir='$tempat_lahir',
                tanggal_lahir='$tanggal_lahir',
                jk='$jk',
                kewarganegaraan='$kewarganegaraan',
                agama='$agama',
                email='$email',
                no_telp='$no_telp',
                alamat='$alamat',
                kode_pos='$kode_pos',
                provinsi='$provinsi',
                kabupaten='$kabupaten',
                kecamatan='$kecamatan',
                pendidikan='$pendidikan',
                sekolah='$sekolah',
                angkatan='$angkatan',
                id_program_studi='$program_studi',
                id_semester='$id_semester',
                dosen_pembimbing='$dosen_pembimbing'
                where id_mahasiswa=$id_mahasiswa";
            }

            //Mengeksekusi query 
            $edit_mahasiswa=mysqli_query($kon,$sql);

            if ($edit_mahasiswa) {
                mysqli_query($kon,"COMMIT");
                header("Location:../../index.php?page=mahasiswa&edit=berhasil");
            }
            else {
                mysqli_query($kon,"ROLLBACK");
                header("Location:../../index.php?page=mahasiswa&edit=gagal");
            }
        } 
    }
?>

<?php 
    include '../../config/database.php';
    $id_mahasiswa=$_POST["id_mahasiswa"];
    $sql="select * from mahasiswa where id_mahasiswa=$id_mahasiswa limit 1";
    $hasil=mysqli_query($kon,$sql);
    $data = mysqli_fetch_array($hasil); 
?>

<form action="apps/mahasiswa/edit.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <input type="hidden" name="id_mahasiswa" class="form-control" value="<?php echo $data['id_mahasiswa'];?>">
    </div>
    <div class="row">
        <div class="col-sm-7">
            <div class="form-group">
                <label>Nama Lengkap :</label>
                <input type="text" name="nama_mahasiswa" class="form-control" value="<?php echo $data['nama_mahasiswa'];?>" placeholder="Masukan Nama Lengkap" required>
            </div>
        </div>
        <div class="col-sm-5">
            <div class="form-group">
                <label>Nomor Induk Mahasiswa (NIM) :</label>
                <input type="text" name="nim" class="form-control" value="<?php echo $data['nim'];?>" placeholder="Masukan Nomor Induk Mahasiswa" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Tempat Lahir :</label>
                <input type="text" name="tempat_lahir" class="form-control" value="<?php echo $data['tempat_lahir'];?>" placeholder="Masukan Tempat Lahir" required>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>Tanggal Lahir :</label>
                <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo $data['tanggal_lahir'];?>" required>
            </div>
        </div>
        <div class="col-sm-5">
            <div class="form-group">
                <label>Jenis Kelamin :</label>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" <?php if (isset($data['jk']) && $data['jk']==1) echo "checked"; ?> class="form-check-input" name="jk" value="1" required>Laki-laki
                    </label>
                    <label class="form-check-label">
                        <input type="radio" <?php if (isset($data['jk']) && $data['jk']==2) echo "checked"; ?> class="form-check-input" name="jk" value="2" required>Perempuan
                    </label>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Kewarganegaraan :</label>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" <?php if (isset($data['kewarganegaraan']) && $data['kewarganegaraan']=="WNI") echo "checked"; ?> class="form-check-input" name="kewarganegaraan" value="WNI" required>WNI
                    </label>
                    <label class="form-check-label">
                        <input type="radio" <?php if (isset($data['kewarganegaraan']) && $data['kewarganegaraan']=="WNA") echo "checked"; ?> class="form-check-input" name="kewarganegaraan" value="WNA" required>WNA
                    </label>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>Agama :</label>
                <select class="form-control" name="agama" required>
                    <?php
                    $daftar_agama = array("Islam", "Kristen", "Katolik","Hindu","Budha","Lainnya");
                    $jum=count($daftar_agama)-1;
                    for ($i=0;$i<=$jum;$i++):
                    ?>
                    <option <?php if ($daftar_agama[$i]==$data['agama']) echo "selected"; ?> value="<?php echo $daftar_agama[$i];?>"><?php echo $daftar_agama[$i];?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Email :</label>
                <input type="email" name="email" class="form-control" value="<?php echo $data['email'];?>" placeholder="Masukan Email" required>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>No Telp :</label>
                <input type="text" name="no_telp" class="form-control" value="<?php echo $data['no_telp'];?>" placeholder="Masukan No Telp" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-5">
            <div class="form-group">
                <label>Alamat :</label>
                <textarea class="form-control" name="alamat" rows="2" id="alamat"><?php echo $data['alamat'];?></textarea>
            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <label>Kode Pos :</label>
                <input type="text" name="kode_pos" class="form-control" value="<?php echo $data['kode_pos'];?>" placeholder="Kode Pos"/>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Provinsi :</label>
                <select class="form-control" name="provinsi" id="provinsi" required>
                    <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel provinsi
                    $sql="select * from provinsi";
                    $hasil=mysqli_query($kon,$sql);
                    while ($row = mysqli_fetch_array($hasil)) {
                        ?>
                    <option <?php if ($data['provinsi']==$row['id_prov']) echo "selected"; ?> value="<?php echo $row['id_prov'];?>"><?php echo $row['nama'];?></option>
                    <?php
                        }
                    ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Kabupaten :</label>
                <select class="form-control" name="kabupaten" id="kabupaten" required>
                    <!-- Kabupaten akan diload menggunakan ajax, dan ditampilkan disini -->
                    <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel kabupaten
                    $sql="select * from kabupaten";
                    $hasil=mysqli_query($kon,$sql);
                    while ($row = mysqli_fetch_array($hasil)) {
                        ?>
                    <option <?php if ($data['kabupaten']==$row['id_kab']) echo "selected"; ?> value="<?php echo $row['id_kab'];?>"><?php echo $row['nama'];?></option>
                    <?php
                        }
                    ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Kecamatan :</label>
                <select class="form-control" name="kecamatan" id="kecamatan" required>
                    <!-- Kecamatan akan diload menggunakan ajax, dan ditampilkan disini -->
                    
                    <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel kecamatan
                    $sql="select * from kecamatan";
                    $hasil=mysqli_query($kon,$sql);
                    while ($row = mysqli_fetch_array($hasil)) {
                        ?>
                    <option <?php if ($data['kecamatan']==$row['id_kec']) echo "selected"; ?> value="<?php echo $row['id_kec'];?>"><?php echo $row['nama'];?></option>
                    <?php
                        }
                    ?>
                </select>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Pendidikan Terakhir :</label>
                <select class="form-control" name="pendidikan" required>
                    <?php
                    $daftar_pendidikan = array("SMA-IPA", "SMA-IPS", "SMK-IPA","SMK-IPS");
                    $jum=count($daftar_pendidikan)-1;
                    for ($i=0;$i<=$jum;$i++):
                    ?>
                    <option <?php if ($daftar_pendidikan[$i]==$data['pendidikan']) echo "selected"; ?> value="<?php echo $daftar_pendidikan[$i];?>"><?php echo $daftar_pendidikan[$i];?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Nama Sekolah :</label>
                <input type="text" name="sekolah" class="form-control" value="<?php echo $data["sekolah"];?>" placeholder="Masukan Nama Sekolah" required>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Angkatan :</label>
                <input type="text" name="angkatan" class="form-control" value="<?php echo $data['angkatan'];?>" placeholder="Masukan Tahun Angkatan">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Program Studi :</label>
                <select class="form-control" name="program_studi" required>
                <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel program_studi
                    $sql="select * from program_studi";
                    $hasil=mysqli_query($kon,$sql);
                    while ($row = mysqli_fetch_array($hasil)) {
                        ?>
                    <option <?php if ($data['id_program_studi']==$row['id_program_studi']) echo "selected"; ?> value="<?php echo $row['id_program_studi'];?>"><?php echo $row['program_studi'];?></option>
                    <?php
                    }
                ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Semester :</label>
                <select class="form-control" name="id_semester" required>
                <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel program_studi
                    $sql="select * from semester";
                    $hasil=mysqli_query($kon,$sql);
                    while ($row = mysqli_fetch_array($hasil)) {
                        ?>
                    <option <?php if ($data['id_semester']==$row['semester']) echo "selected"; ?> value="<?php echo $row['id_semester'];?>"><?php echo $row['semester'];?></option>
                    <?php
                    }
                ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Dosen Pembimbing :</label>
                <select class="form-control" name="dosen_pembimbing" required>
                <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel dosen
                    $sql="select * from dosen";
                    $hasil=mysqli_query($kon,$sql);
                    while ($row = mysqli_fetch_array($hasil)) {
                        ?>
                    <option <?php if ($data['dosen_pembimbing']==$row['id_dosen']) echo "selected"; ?> value="<?php echo $row['id_dosen'];?>"><?php echo $row['nama_dosen'];?></option>
                    <?php
                    }
                ?>
                </select>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
        <label>Foto:</label><br>
            <img src="apps/mahasiswa/foto/<?php echo $data['foto'];?>" id="preview" width="90%" class="rounded" alt="Cinque Terre">
            <input type="hidden" name="foto_saat_ini" value="<?php echo $data['foto'];?>" class="form-control" />
        </div>
        <div class="col-sm-4">
            <div id="msg"></div>
            <label>Upload Foto Baru:</label>
            <input type="file" name="foto_baru" class="file" >
            <div class="input-group my-3">
                <input type="text" class="form-control" disabled placeholder="Upload File" id="file">
                <div class="input-group-append">
                        <button type="button" id="pilih_foto" class="browse btn btn-info"><i class="fa fa-search"></i> Pilih Foto</button>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <button type="submit" name="edit_mahasiswa" id="Submit" class="btn btn-warning"><i class="fa fa-edit"></i> Update</button>
        </div>
    </div>
</form>

<script>
    $("#provinsi").change(function() {
        // variabel dari nilai combo provinsi
        var id_provinsi = $("#provinsi").val();

        // Menggunakan ajax untuk mengirim dan dan menerima data dari server
        $.ajax({
            type: "POST",
            dataType: "html",
            url: 'apps/mahasiswa/data-provinsi.php',
            data: "provinsi=" + id_provinsi,
            success: function(data) {
                $("#kabupaten").html(data);
            }
        });
    });

    $("#kabupaten").change(function() {
        // variabel dari nilai combo box kabupaten
        var id_kabupaten = $("#kabupaten").val();

        // Menggunakan ajax untuk mengirim dan dan menerima data dari server
        $.ajax({
            type: "POST",
            dataType: "html",
            url: 'apps/mahasiswa/data-provinsi.php',
            data: "kabupaten=" + id_kabupaten,
            success: function(data) {
                $("#kecamatan").html(data);
            }
        });
    });
    </script>

<style>
    .file {
    visibility: hidden;
    position: absolute;
    }
</style>

<script>
    $(document).on("click", "#pilih_foto", function() {
    var file = $(this).parents().find(".file");
    file.trigger("click");
    });
    $('input[type="file"]').change(function(e) {
    var fileName = e.target.files[0].name;
    $("#file").val(fileName);

    var reader = new FileReader();
    reader.onload = function(e) {
        // get loaded data and render thumbnail.
        document.getElementById("preview").src = e.target.result;
    };
    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
    });

</script>
