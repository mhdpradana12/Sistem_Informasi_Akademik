<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=beranda">
                <em class="fa fa-home"></em>
            </a></li>
        <li class="active">Profil</li>
    </ol>
</div><!--/.row-->



<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
            Profil
            <span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
            <div class="panel-body">
            <?php 
                include 'config/database.php';
                $kode_pengguna=$_SESSION["kode_pengguna"];
                $sql="select m.*,p.nama as nama_provinsi,k.nama as nama_kab, t.nama as nama_kec, s.* from mahasiswa m
                inner join program_studi s on s.id_program_studi=m.id_program_studi
                inner join provinsi p on p.id_prov=m.provinsi
                inner join kabupaten k on k.id_kab=m.kabupaten
                inner join kecamatan t on t.id_kec=m.kecamatan
                where m.kode_mahasiswa='$kode_pengguna' limit 1";
                $hasil=mysqli_query($kon,$sql);
                $data = mysqli_fetch_array($hasil); 
            ?>

            <?php
                //Validasi untuk menampilkan pesan pemberitahuan saat user setting username dan password 
                if (isset($_GET['pengguna'])) {
                    if ($_GET['pengguna']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Ubah Password berhasil</div>";
                    }else if ($_GET['pengguna']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Ubah Password gagal</div>";
                    }    
                }
            ?>
                
                <table class="table">
                    <tbody>
                        <tr>
                            <td>NIM</td>
                            <td width="75%">: <?php echo $data['nim'];?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td width="75%">: <?php echo $data['nama_mahasiswa'];?></td>
                        </tr>
                        <tr>
                            <td>Tempat Lahir</td>
                            <td width="75%">: <?php echo $data['tempat_lahir'];?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Lahir</td>
                            <td width="75%">: <?php echo date('d/m/Y', strtotime($data["tanggal_lahir"]));?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td width="75%">: <?php echo $data['jk'] == 1 ? 'Laki-laki' : 'Perempuan'; ?></td>
                        </tr>
                        <tr>
                            <td>Kewarganegaraan</td>
                            <td width="75%">: <?php echo $data['kewarganegaraan'];?></td>
                        </tr>
                        <tr>
                            <td>Agama</td>
                            <td width="75%">: <?php echo $data['agama'];?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td width="75%">: <?php echo $data['email'];?></td>
                        </tr>
                        <tr>
                            <td>No Telp</td>
                            <td width="75%">: <?php echo $data['no_telp'];?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td width="75%">: <?php echo $data['alamat'];?></td>
                        </tr>
                        <tr>
                            <td>Kode POS</td>
                            <td width="75%">: <?php echo $data['kode_pos'];?></td>
                        </tr>
                        <tr>
                            <td>Provinsi</td>
                            <td width="75%">: <?php echo $data['nama_provinsi'];?></td>
                        </tr>
                        <tr>
                            <td>Kabupaten</td>
                            <td width="75%">: <?php echo $data['nama_kab'];?></td>
                        </tr>
                        <tr>
                            <td>Kecamatan</td>
                            <td width="75%">: <?php echo $data['nama_kec'];?></td>
                        </tr>
                        <tr>
                            <td>Pendidikan</td>
                            <td width="75%">: <?php echo $data['pendidikan'];?></td>
                        </tr>
                        <tr>
                            <td>Sekolah</td>
                            <td width="75%">: <?php echo $data['sekolah'];?></td>
                        </tr>
                        <tr>
                            <td>Tahun Angkatan</td>
                            <td width="75%">: <?php echo $data['angkatan'];?></td>
                        </tr>
                        <tr>
                            <td>Program Studi</td>
                            <td width="75%">: <?php echo $data['program_studi'];?></td>
                        </tr>
                    </tbody>
                </table>
                <div class="form-group">
                <button kode_mahasiswa="<?php echo $data['kode_mahasiswa'];?>" class="ubah_password btn btn-info btn-circle" ><i class="fa fa-key"></i> Ubah Password</button>
                </div>
            </div>
        </div>
    </div>
</div><!--/.row-->

<!-- Modal -->
<div class="modal fade" id="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

        <div class="modal-header">
            <h4 class="modal-title" id="judul"></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <div class="modal-body">
            <div id="tampil_data">
                 <!-- Data akan di load menggunakan AJAX -->                   
            </div>  
        </div>
  
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        </div>

        </div>
    </div>
</div>

<script>
    // Setting pengguna
    $('.ubah_password').on('click',function(){
        var kode_mahasiswa = $(this).attr("kode_mahasiswa");
        $.ajax({
            url: 'apps/mahasiswa/ubah-password.php',
            method: 'post',
            data: {kode_mahasiswa:kode_mahasiswa},
            success:function(data){
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML='Ubah Password';
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>