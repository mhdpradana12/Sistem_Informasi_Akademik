<?php 
  if ($_SESSION["level"]!='Admin' and $_SESSION["level"]!='Admin'){
    echo"<br><div class='alert alert-danger'>Tidak Memiliki Hak Akses</div>";
    exit;
  }
?>
<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=beranda">
                <em class="fa fa-home"></em>
            </a></li>
        <li class="active">Data Mahasiswa</li>
    </ol>
</div><!--/.row-->


<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
            Data Mahasiswa
                <span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
            <div class="panel-body">
                <div class="row">
                    <form action="#" method="get">
                    <input type="hidden" name="page" value="mahasiswa"/>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select class="form-control" name="program_studi" required>
                                    <option value="">Pilih Program Studi</option>
                                    <?php
                                    include 'config/database.php';
                                    $ket="";
                                    //Perintah sql untuk menampilkan semua data pada tabel program_studi
                                    $hasil=mysqli_query($kon,"select * from program_studi");
                                    while ($data = mysqli_fetch_array($hasil)) {
                                        if (isset($_GET['program_studi'])) {
                                            $program_studi = trim($_GET['program_studi']);
                            
                                            if ($program_studi==$data['id_program_studi'])
                                            {
                                                $ket="selected";
                                            }else {
                                                $ket="";
                                            }
                                        }
                                    ?>
                                    <option <?php echo $ket; ?> value="<?php echo $data['id_program_studi'];?>"  ><?php echo $data['program_studi'];?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select class="form-control" name="semester" required>
                                    <option value="">Pilih Semester</option>
                                    <?php
                                    include 'config/database.php';
                                    $ket="";
                                    //Perintah sql untuk menampilkan semua data pada tabel program_studi
                                    $hasil=mysqli_query($kon,"select * from semester");
                                    while ($data = mysqli_fetch_array($hasil)) {
                                        if (isset($_GET['semester'])) {
                                            $semester = trim($_GET['semester']);
                            
                                            if ($semester==$data['id_semester'])
                                            {
                                                $ket="selected";
                                            }else {
                                                $ket="";
                                            }
                                        }
                                    ?>
                                    <option <?php echo $ket; ?> value="<?php echo $data['id_semester'];?>"  ><?php echo $data['semester'];?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> Pilih</button>
                            </div>
                        </div>
                    </form>
                </div>
    
            </div>
        </div>
    </div>
</div><!--/.row-->

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
            <?php
                //Validasi untuk menampilkan pesan pemberitahuan saat user menambah Mahasiswa
                if (isset($_GET['add'])) {
                    if ($_GET['add']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Data Mahasiswa Telah Disimpan</div>";
                    }else if ($_GET['add']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Data Mahasiswa Gagal Disimpan</div>";
                    }    
                }

                //Validasi untuk menampilkan pesan pemberitahuan saat user setting username dan password 
                if (isset($_GET['pengguna'])) {
                    if ($_GET['pengguna']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Setting Akun Pengguna berhasil</div>";
                    }else if ($_GET['pengguna']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Setting Akun Pengguna gagal</div>";
                    }    
                }

                //Validasi untuk menampilkan pesan pemberitahuan saat user mengedit Mahasiswa
                if (isset($_GET['edit'])) {
                    if ($_GET['edit']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Data Mahasiswa Telah Diupdate</div>";
                    }else if ($_GET['edit']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Data Mahasiswa Gagal Diupdate</div>";
                    }    
                }

                //Validasi untuk menampilkan pesan pemberitahuan saat user menghapus Mahasiswa
                if (isset($_GET['hapus'])) {
                    if ($_GET['hapus']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Data Mahasiswa Telah Dihapus</div>";
                    }else if ($_GET['hapus']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Data Mahasiswa Gagal Dihapus</div>";
                    }    
                }
            ?>
                <div class="form-group">
                    <button type="button" class="btn btn-success" id="tombol_tambah"><i class="fa fa-plus"></i>  Tambah</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIM</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Program Studi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
        
                        <tbody>
                        <?php
                            // include database
                            include 'config/database.php';
                            
                            if (isset($_GET['program_studi']) and $_GET['semester'] and $_GET['program_studi']!="" and $_GET['semester']!="") {
                                $id_program_studi=trim($_GET["program_studi"]);
                                $id_semester=trim($_GET["semester"]);
                                $sql="select * from mahasiswa m inner join program_studi p on p.id_program_studi=m.id_program_studi inner join semester s on s.id_semester=m.id_semester where p.id_program_studi=$id_program_studi and s.id_semester=$id_semester";
                            }else {
                                $sql="select * from mahasiswa m inner join program_studi p on p.id_program_studi=m.id_program_studi inner join semester s on s.id_semester=m.id_semester";
                            }
                            
                            $hasil=mysqli_query($kon,$sql);
                            $no=0;
                            //Menampilkan data dengan perulangan while
                            while ($data = mysqli_fetch_array($hasil)):
                            $no++;
                        ?>
                        <tr>
                            <td><?php echo $no; ?></td>
                            <td><?php echo $data['nim']; ?></td>
                            <td><?php echo $data['nama_mahasiswa']; ?></td>
                            <td><?php echo $data['jk'] == 1 ? 'Laki-laki' : 'Perempuan';?></td>
                            <td><?php echo $data['program_studi']; ?></td>
                            <td>
                                <button id_mahasiswa="<?php echo $data['id_mahasiswa'];?>" class="tombol_detail btn btn-success btn-circle" ><i class="fa fa-mouse-pointer"></i></button>
                                <button kode_mahasiswa="<?php echo $data['kode_mahasiswa'];?>" class="tombol_setting_pengguna btn btn-primary btn-circle" ><i class="fa fa-user"></i></button>
                                <button id_mahasiswa="<?php echo $data['id_mahasiswa'];?>" class="tombol_edit btn btn-warning btn-circle" ><i class="fa fa-edit"></i></button>
                                <a href="apps/mahasiswa/hapus.php?id_mahasiswa=<?php echo $data['id_mahasiswa']; ?>&kode_mahasiswa=<?php echo $data['kode_mahasiswa']; ?>" class="btn-hapus-mahasiswa btn btn-danger btn-circle" ><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <!-- bagian akhir (penutup) while -->
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><!--/.row-->


<!-- Modal -->
<div class="modal fade" id="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

        <div class="modal-header">
            <h4 class="modal-title" id="judul"></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <div class="modal-body">
            <div id="tampil_data">
                 <!-- Data akan di load menggunakan AJAX -->                   
            </div>  
        </div>
  
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        </div>

        </div>
    </div>
</div>

<script>
    // Tambah mahasiswa
    $('#tombol_tambah').on('click',function(){
        $.ajax({
            url: 'apps/mahasiswa/tambah.php',
            method: 'post',
            success:function(data){
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML='Tambah Mahasiswa';
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>

<script>
    // Detail mahasiswa
    $('.tombol_detail').on('click',function(){
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        $.ajax({
            url: 'apps/mahasiswa/detail.php',
            method: 'post',
            data: {id_mahasiswa:id_mahasiswa},
            success:function(data){
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML='Detail Mahasiswa';
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>

<script>
    // Setting pengguna
    $('.tombol_setting_pengguna').on('click',function(){
        var kode_mahasiswa = $(this).attr("kode_mahasiswa");
        $.ajax({
            url: 'apps/mahasiswa/setting-pengguna.php',
            method: 'post',
            data: {kode_mahasiswa:kode_mahasiswa},
            success:function(data){
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML='Setting Akun';
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>

<script>
    // Edit mahasiswa
    $('.tombol_edit').on('click',function(){
        var id_mahasiswa = $(this).attr("id_mahasiswa");
        $.ajax({
            url: 'apps/mahasiswa/edit.php',
            method: 'post',
            data: {id_mahasiswa:id_mahasiswa},
            success:function(data){
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML='Edit Mahasiswa';
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>

<script>
   // fungsi hapus mahasiswa
   $('.btn-hapus-mahasiswa').on('click',function(){
        konfirmasi=confirm("Yakin ingin menghapus mahasiswa ini?")
        if (konfirmasi){
            return true;
        }else {
            return false;
        }
    });
</script>
