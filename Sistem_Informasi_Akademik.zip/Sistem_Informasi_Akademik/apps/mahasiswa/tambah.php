<?php
session_start();
    if (isset($_POST['tambah_mahasiswa'])) {
        
        //Include file koneksi, untuk koneksikan ke database
        include '../../config/database.php';
        
        //Fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        //Cek apakah ada kiriman form dari method post
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            //Memulai transaksi
            mysqli_query($kon,"START TRANSACTION");

            $nama_mahasiswa=input($_POST["nama_mahasiswa"]);
            $nim=input($_POST["nim"]);
            $tempat_lahir=input($_POST["tempat_lahir"]);
            $tanggal_lahir=input($_POST["tanggal_lahir"]);
            $jk=input($_POST["jk"]);
            $kewarganegaraan=input($_POST["kewarganegaraan"]);
            $agama=input($_POST["agama"]);
            $email=input($_POST["email"]);
            $no_telp=input($_POST["no_telp"]);
            $alamat=input($_POST["alamat"]);
            $kode_pos=input($_POST["kode_pos"]);
            $provinsi=input($_POST["provinsi"]);
            $kabupaten=input($_POST["kabupaten"]);
            $kecamatan=input($_POST["kecamatan"]);
            $pendidikan=input($_POST["pendidikan"]);
            $sekolah=input($_POST["sekolah"]);
            $angkatan=input($_POST["angkatan"]);
            $id_program_studi=input($_POST["id_program_studi"]);
            $id_semester=input($_POST["id_semester"]);
            $dosen_pembimbing=input($_POST["dosen_pembimbing"]);

            $ekstensi_diperbolehkan	= array('png','jpg','jpeg','gif');
            $foto = $_FILES['foto']['name'];
            $x = explode('.', $foto);
            $ekstensi = strtolower(end($x));
            $ukuran	= $_FILES['foto']['size'];
            $file_tmp = $_FILES['foto']['tmp_name'];
     
            include '../../config/database.php';
            $query = mysqli_query($kon, "SELECT max(id_mahasiswa) as id_terbesar FROM mahasiswa");
            $ambil = mysqli_fetch_array($query);
            $id_mhs = $ambil['id_terbesar'];
            $id_mhs++;

            //Membuat kode mahasiswa
            $huruf = "M";
            $kode_mahasiswa = $huruf . sprintf("%03s", $id_mhs);

            if (!empty($foto)){
                if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
                    //Mengupload gambar
                    move_uploaded_file($file_tmp, 'foto/'.$foto);
                    //Sql jika menggunakan foto
                    $sql="insert into mahasiswa (kode_mahasiswa,nama_mahasiswa,nim,tempat_lahir,tanggal_lahir,jk,kewarganegaraan,agama,email,no_telp,alamat,kode_pos,provinsi,kabupaten,kecamatan,pendidikan,sekolah,angkatan,id_program_studi,id_semester,dosen_pembimbing,foto) values
                    ('$kode_mahasiswa','$nama_mahasiswa','$nim','$tempat_lahir','$tanggal_lahir','$jk','$kewarganegaraan','$agama','$email','$no_telp','$alamat','$kode_pos','$provinsi','$kabupaten','$kecamatan','$pendidikan','$sekolah','$angkatan','$id_program_studi','$id_semeseter','$dosen_pembimbing','$foto')";
                }
            }else {
                //Sql jika tidak menggunakan foto, maka akan memakai gambar_default.png
                $foto="foto_default.png";
                $sql="insert into mahasiswa (kode_mahasiswa,nama_mahasiswa,nim,tempat_lahir,tanggal_lahir,jk,kewarganegaraan,agama,email,no_telp,alamat,kode_pos,provinsi,kabupaten,kecamatan,pendidikan,sekolah,angkatan,id_program_studi,id_semester,dosen_pembimbing,foto) values
                ('$kode_mahasiswa','$nama_mahasiswa','$nim','$tempat_lahir','$tanggal_lahir','$jk','$kewarganegaraan','$agama','$email','$no_telp','$alamat','$kode_pos','$provinsi','$kabupaten','$kecamatan','$pendidikan','$sekolah','$angkatan','$id_program_studi','$id_semester','$dosen_pembimbing','$foto')";
            }
    

            //Menyimpan ke tabel mahasiswa
            $simpan_mahasiswa=mysqli_query($kon,$sql);
  
            $sql="insert into pengguna (kode_pengguna) values
            ('$kode_mahasiswa')";

            //Menyimpan ke tabel pengguna
            $simpan_pengguna=mysqli_query($kon,$sql);

            if ($simpan_mahasiswa and  $simpan_pengguna) {
                mysqli_query($kon,"COMMIT");
                header("Location:../../index.php?page=mahasiswa&add=berhasil");
            }
            else {
                mysqli_query($kon,"ROLLBACK");
                header("Location:../../index.php?page=mahasiswa&add=gagal");
            }
        } 
    }
?>

<?php
    //Membuat Nomor Induk Mahasiswa kombinasi dari tahun dan program studi
    include '../../config/database.php';
    $query = mysqli_query($kon, "SELECT max(id_mahasiswa) as id_terbesar FROM mahasiswa");
    $ambil = mysqli_fetch_array($query);
    $id_mhs = $ambil['id_terbesar'];
    $id_mhs++;
    $tahun=date('y');
    $kode_depan = $tahun.'01';
    $nim = $kode_depan . sprintf("%03s", $id_mhs);
?>

<form action="apps/mahasiswa/tambah.php" method="post"  enctype="multipart/form-data">
    <div class="row">
        <div class="col-sm-7">
            <div class="form-group">
                <label>Nama Lengkap :</label>
                <input type="text" name="nama_mahasiswa" class="form-control" placeholder="Masukan Nama Lengkap" required>
            </div>
        </div>
        <div class="col-sm-5">
            <div class="form-group">
                <label>Nomor Induk Mahasiswa (NIM) :</label>
                <input type="text" name="nim" class="form-control" value="<?php echo $nim; ?>" placeholder="Masukan Nomor Induk Mahasiswa" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Tempat Lahir :</label>
                <input type="text" name="tempat_lahir" class="form-control" placeholder="Masukan Tempat Lahir" required>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>Tanggal Lahir :</label>
                <input type="date" name="tanggal_lahir" class="form-control" required>
            </div>
        </div>
        <div class="col-sm-5">
            <div class="form-group">
                <label>Jenis Kelamin :</label>
                <select class="form-control" name="jk" required>
                    <option>Pilih</option>
                    <option value="1">Laki-laki</option>
                    <option value="2">Perempuan</option>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Kewarganegaraan :</label>
                <select class="form-control" name="kewarganegaraan" required>
                    <option>Pilih</option>
                    <option value="WNI">Warga Negara Indonesia</option>
                    <option value="WNA">Warga Negara Asing</option>
                </select>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>Agama :</label>
                <select class="form-control" name="agama" required>
                    <option>Pilih</option>
                    <option value="Islam">Islam</option>
                    <option value="Kristen">Kristen</option>
                    <option value="Katolik">Katolik</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Budha">Budha</option>
                    <option value="Lainnya">Lainnya</option>
                </select>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Email :</label>
                <input type="email" name="email" class="form-control" placeholder="Masukan Email" required>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="form-group">
                <label>No Telp :</label>
                <input type="text" name="no_telp" class="form-control" placeholder="Masukan No Telp" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-5">
            <div class="form-group">
                <label>Alamat :</label>
                <textarea class="form-control" name="alamat" rows="2" id="alamat"></textarea>
            </div>
        </div>
        <div class="col-sm-2">
            <div class="form-group">
                <label>Kode Pos :</label>
                <input type="text" name="kode_pos" class="form-control" placeholder="Kode Pos">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Provinsi :</label>
                <select class="form-control" name="provinsi" id="provinsi" required>
                    <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel provinsi
                    $sql="select * from provinsi";
                    $hasil=mysqli_query($kon,$sql);
                    while ($data = mysqli_fetch_array($hasil)) {
                        ?>
                    <option value="<?php echo $data['id_prov'];?>"><?php echo $data['nama'];?></option>
                    <?php
                        }
                ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Kabupaten :</label>
                <select class="form-control" name="kabupaten" id="kabupaten" required>
                    <!-- Kabupaten akan diload menggunakan ajax, dan ditampilkan disini -->
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Kecamatan :</label>
                <select class="form-control" name="kecamatan" id="kecamatan" required>
                    <!-- Kecamatan akan diload menggunakan ajax, dan ditampilkan disini -->
                </select>
            </div>
        </div>
    </div>

    <script>
    $("#provinsi").change(function() {
        // variabel dari nilai combo provinsi
        var id_provinsi = $("#provinsi").val();

        // Menggunakan ajax untuk mengirim dan dan menerima data dari server
        $.ajax({
            type: "POST",
            dataType: "html",
            url: 'apps/mahasiswa/data-provinsi.php',
            data: "provinsi=" + id_provinsi,
            success: function(data) {
                $("#kabupaten").html(data);
            }
        });
    });

    $("#kabupaten").change(function() {
        // variabel dari nilai combo box kabupaten
        var id_kabupaten = $("#kabupaten").val();

        // Menggunakan ajax untuk mengirim dan dan menerima data dari server
        $.ajax({
            type: "POST",
            dataType: "html",
            url: 'apps/mahasiswa/data-provinsi.php',
            data: "kabupaten=" + id_kabupaten,
            success: function(data) {
                $("#kecamatan").html(data);
            }
        });
    });
    </script>

    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Pendidikan Terakhir :</label>
                <select class="form-control" name="pendidikan" required>
                    <option value="SMA-IPA">SMA - IPA</option>
                    <option value="SMA-IPS">SMA - IPS</option>
                    <option value="SMK-IPA">SMK - IPA</option>
                    <option value="SMK-IPS">SMK - IPS</option>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Nama Sekolah :</label>
                <input type="text" name="sekolah" class="form-control" placeholder="Masukan Nama Sekolah" required>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Tahun Angkatan :</label>
                <input type="text" name="angkatan" class="form-control" value="<?php echo date('Y'); ?>" placeholder="Masukan Tahun Angkatan">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="form-group">
                <label>Program Studi :</label>
                <select class="form-control" name="id_program_studi" required>
                <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel program_studi
                    $sql="select * from program_studi";
                    $hasil=mysqli_query($kon,$sql);
                    while ($data = mysqli_fetch_array($hasil)) {
                        ?>
                    <option value="<?php echo $data['id_program_studi'];?>"><?php echo $data['program_studi'];?></option>
                    <?php
                        }
                ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Semester :</label>
                <select class="form-control" name="id_semester" required>
                <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel semester
                    $sql="select * from semester";
                    $hasil=mysqli_query($kon,$sql);
                    while ($data = mysqli_fetch_array($hasil)) {
                        ?>
                    <option value="<?php echo $data['id_semester'];?>"><?php echo $data['semester'];?></option>
                    <?php
                        }
                ?>
                </select>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                <label>Dosen Pembimbing :</label>
                <select class="form-control" name="dosen_pembimbing" required>
                <?php
                    include '../../config/database.php';
                    //Perintah sql untuk menampilkan semua data pada tabel dosen
                    $sql="select * from dosen";
                    $hasil=mysqli_query($kon,$sql);
                    while ($data = mysqli_fetch_array($hasil)) {
                        ?>
                    <option value="<?php echo $data['id_dosen'];?>"><?php echo $data['nama_dosen'];?></option>
                    <?php
                        }
                ?>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-5">
            <div class="form-group">
                <div id="msg"></div>
                <label>Foto:</label>
                <input type="file" name="foto" class="file" >
                    <div class="input-group my-3">
                        <input type="text" class="form-control" disabled placeholder="Upload Foto" id="file">
                        <div class="input-group-append">
                                <button type="button" id="pilih_foto" class="browse btn btn-info"><i class="fa fa-search"></i> Pilih</button>
                        </div>
                    </div>
                <img src="source/img/size.png" id="preview" class="img-thumbnail">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-4">
            <button type="submit" name="tambah_mahasiswa" id="Submit" class="btn btn-success"><i class="fa fa-plus"></i> Daftar</button>
            <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> Reset</button>
        </div>
    </div>
</form>

<style>
    .file {
    visibility: hidden;
    position: absolute;
    }
</style>

<script>
    $(document).on("click", "#pilih_foto", function() {
    var file = $(this).parents().find(".file");
    file.trigger("click");
    });
    $('input[type="file"]').change(function(e) {
    var fileName = e.target.files[0].name;
    $("#file").val(fileName);

    var reader = new FileReader();
    reader.onload = function(e) {
        // get loaded data and render thumbnail.
        document.getElementById("preview").src = e.target.result;
    };
    // read the image file as a data URL.
    reader.readAsDataURL(this.files[0]);
    });

</script>
