<?php 
  if ($_SESSION["level"]!='Dosen' and $_SESSION["level"]!='dosen'){
    echo"<br><div class='alert alert-danger'>Tidak Memiliki Hak Akses</div>";
    exit;
  }
?>

<div class="row">
    <ol class="breadcrumb">
        <li><a href="index.php?page=beranda">
                <em class="fa fa-home"></em>
            </a></li>
        <li class="active">Profil</li>
    </ol>
</div><!--/.row-->

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">

            <?php
                //Validasi untuk menampilkan pesan pemberitahuan saat user setting username dan password 
                if (isset($_GET['pengguna'])) {
                    if ($_GET['pengguna']=='berhasil'){
                        echo"<div class='alert alert-success'><strong>Berhasil!</strong> Ubah Password berhasil</div>";
                    }else if ($_GET['pengguna']=='gagal'){
                        echo"<div class='alert alert-danger'><strong>Gagal!</strong> Ubah Password gagal</div>";
                    }    
                }
            ?>

            <div class="panel-heading">
            Profil
            <span class="pull-right clickable panel-toggle panel-button-tab-left"><em class="fa fa-toggle-up"></em></span></div>
            <div class="panel-body">
                <?php 
                    include 'config/database.php';
                    $kode_pengguna=$_SESSION["kode_pengguna"];
                    $sql="select * from dosen where kode_dosen='$kode_pengguna' limit 1";
                    $hasil=mysqli_query($kon,$sql);
                    $data = mysqli_fetch_array($hasil); 
                ?>
                <table class="table">
                    <tbody>
                        <tr>
                            <td>NIP</td>
                            <td width="75%">: <?php echo $data['nip'];?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td width="75%">: <?php echo $data['nama_dosen'];?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td width="75%">: <?php echo $data['jk'] == 1 ? 'Laki-laki' : 'Perempuan';?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td width="75%">: <?php echo $data['email'];?></td>
                        </tr>
                        <tr>
                            <td>No Telp</td>
                            <td width="75%">: <?php echo $data['no_telp'];?></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td width="75%">: <?php echo $data['alamat'];?></td>
                        </tr>
                    </tbody>
                </table>
                <div class="form-group">
                <button kode_dosen="<?php echo $data['kode_dosen'];?>" class="ubah_password btn btn-info btn-circle" ><i class="fa fa-key"></i> Ubah Password</button>
                </div>
            </div>
        </div>
    </div>
</div><!--/.row-->

<!-- Modal -->
<div class="modal fade" id="modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

        <div class="modal-header">
            <h4 class="modal-title" id="judul"></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <div class="modal-body">
            <div id="tampil_data">
                 <!-- Data akan di load menggunakan AJAX -->                   
            </div>  
        </div>
  
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
        </div>

        </div>
    </div>
</div>

<script>
    // Setting pengguna
    $('.ubah_password').on('click',function(){
        var kode_dosen = $(this).attr("kode_dosen");
        $.ajax({
            url: 'apps/dosen/ubah-password.php',
            method: 'post',
            data: {kode_dosen:kode_dosen},
            success:function(data){
                $('#tampil_data').html(data);  
                document.getElementById("judul").innerHTML='Ubah Password';
            }
        });
        // Membuka modal
        $('#modal').modal('show');
    });
</script>