<?php 
    session_start();

    // Jika terdetesi ada variabel id_pengguna dalam session maka langsung arahkan ke halaman dashboard
    if  (isset($_SESSION["id_pengguna"])){
        session_unset();
        session_destroy();
    }
    
    $pesan="";
    // Fungsi untuk mencegah inputan karakter yang tidak sesuai
    function input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
    }

    // Cek apakah ada kiriman form dari method post
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
        include "config/database.php";
        //Mengambil uername dan password
        $username = input($_POST["username"]);
        $password = input(md5($_POST["password"]));

    // Query untuk cek pada tabel pengguna yang dijoinkan dengan tabel admin
        $tabel_admin= "select * from pengguna p
        inner join admin k on k.kode_admin=p.kode_pengguna
        where username='".$username."' and password='".$password."' limit 1";

        $cek_tabel_admin = mysqli_query ($kon,$tabel_admin);
        $admin = mysqli_num_rows($cek_tabel_admin);

        //Query untuk cek pada tabel pengguna yang dijoinkan dengan tabel dosen
        $tabel_dosen= "select * from pengguna p
        inner join dosen d on d.kode_dosen=p.kode_pengguna
        where username='".$username."' and password='".$password."' limit 1";

        $cek_tabel_dosen = mysqli_query ($kon,$tabel_dosen);
        $dosen = mysqli_num_rows($cek_tabel_dosen);

        //Query untuk cek pada tabel pengguna yang dijoinkan dengan tabel mahasiswa
        $tabel_mahasiswa= "select * from pengguna p
        inner join mahasiswa m on m.kode_mahasiswa=p.kode_pengguna
        where username='".$username."' and password='".$password."' limit 1";

        $cek_tabel_mahasiswa = mysqli_query ($kon,$tabel_mahasiswa);
        $mahasiswa = mysqli_num_rows($cek_tabel_mahasiswa);

        // Kondisi jika pengguna merupakan admin
        if ($admin>0){
            $row = mysqli_fetch_assoc($cek_tabel_admin);
            //menyimpan data admin dalam session
            $_SESSION["id_pengguna"]=$row["id_pengguna"];
            $_SESSION["kode_pengguna"]=$row["kode_pengguna"];
            $_SESSION["nama_admin"]=$row["nama_admin"];
            $_SESSION["username"]=$row["username"];
            $_SESSION["level"]=$row["level"];
            $_SESSION["foto"]=$row["foto"];
            $_SESSION["nip"]=$row["nip"];

            header("Location:index.php?page=beranda");
        }
        // Kondisi jika pengguna merupakan dosen
        else if ($dosen>0){

            $row = mysqli_fetch_assoc($cek_tabel_dosen);
            //menyimpan data dosen dalam session
            $_SESSION["id_pengguna"]=$row["id_pengguna"];
            $_SESSION["kode_pengguna"]=$row["kode_pengguna"];
            $_SESSION["nama_dosen"]=$row["nama_dosen"];
            $_SESSION["username"]=$row["username"];
            $_SESSION["level"]=$row["level"];
            $_SESSION["foto"]=$row["foto"];
            $_SESSION["nip"]=$row["nip"];

            header("Location:index.php?page=beranda");
        }
        // Kondisi jika pengguna merupakan mahasiswa
        else if ($mahasiswa>0){

            $row = mysqli_fetch_assoc($cek_tabel_mahasiswa);
            //menyimpan data mahasiswa dalam session
            $_SESSION["id_pengguna"]=$row["id_pengguna"];
            $_SESSION["kode_pengguna"]=$row["kode_pengguna"];
            $_SESSION["nama_mahasiswa"]=$row["nama_mahasiswa"];
            $_SESSION["username"]=$row["username"];
            $_SESSION["level"]=$row["level"];
            $_SESSION["foto"]=$row["foto"];
            $_SESSION["nim"]=$row["nim"];

            header("Location:index.php?page=beranda");
        } else {
            $pesan="<div class='alert alert-danger'><strong>Error!</strong> Username dan Password Salah.</div>";
        }
	}
?>


<?php
    //Mengambil profil aplikasi
    include 'config/database.php';
    $query = mysqli_query($kon, "select * from profil_aplikasi limit 1");    
    $row = mysqli_fetch_array($query);
    $nama_kampus=$row['nama_kampus'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Favicon -->
    <link rel="shortcut icon" href="source/img/favicon.ico">

    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="template/login/css/bootstrap.min.css"/>

    <!-- Google Font Roboto -->
    <link href="template/login/font/" rel="stylesheet" />

    <!-- Custom CSS -->
    <style>
    body {
        font-family: "Roboto Condensed", sans-serif;
        background: url("source/img/bg-login.jpg");
        background-size: cover;
        }
    </style>

    <!-- Title Website -->
    <title>Halaman Login</title>
</head>

<body>
    <div class="container rounded shadow-lg px-4 py-5 mt-5 bg-white" style="max-width: 420px">
    <h1 class="text-center mb-4">Selamat Datang</h1>
        <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
        <label for="info">Silahkan Login Terlebih Dahulu</label>
            <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" name="username" id="username"/>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" name="password" id="password"/>
        </div>
            <?php   if ($_SERVER["REQUEST_METHOD"] == "POST") echo $pesan; ?>
        <button type="submit" name="submit" class="btn btn-primary w-75 btn-block mx-auto">Masuk</button>
        </form>
    </div>
</body>
</html>