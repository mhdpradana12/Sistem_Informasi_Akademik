/* 
login admin 
username : gustav / pradana
passwd   : 123456

login dosen
username : 1506001
passwd   : 1506001

login mahasiswa
username : 2001001
passwd   : 2001001
*/